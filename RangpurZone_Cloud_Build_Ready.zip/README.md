# Rangpur Zone — Full Android Marketplace MVP

Rangpur Zone is a Bangladesh-focused electronics buy/sell marketplace starter.

Included:
- Home, categories, search/filter UI
- Product details
- Wishlist
- Cart and checkout flow
- COD / bKash / Nagad payment selection UI
- Order tracking UI
- Seller: add product + seller dashboard UI
- Profile, orders, settings, notifications
- Login/signup UI
- Dark marketplace branding
- Local demo data so the app can be explored without a server

Production integrations still need your own:
1. Firebase project + google-services.json for real authentication/database/storage.
2. bKash/Nagad merchant credentials and approved API integration.
3. A shipping/courier API or your own delivery workflow.
4. Admin web panel/backend deployment.
5. Real product image storage/CDN.
6. Privacy policy, terms, seller verification and moderation rules.

Open the folder in Android Studio and sync Gradle. Then Run.
