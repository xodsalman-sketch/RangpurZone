package com.rangpurzone.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BG = Color(0xFF071014)
private val CARD = Color(0xFF102027)
private val CARD2 = Color(0xFF132A32)
private val GREEN = Color(0xFF00E676)
private val MUTED = Color(0xFF91A3AA)
private val WHITE = Color(0xFFF5F7F8)

data class Product(
    val id: Int,
    val name: String,
    val price: Int,
    val category: String,
    val condition: String,
    val seller: String,
    val location: String = "Rangpur"
)

val demoProducts = listOf(
    Product(1,"iPhone 15 Pro Max 256GB",145000,"Mobile","Brand New","Rangpur Gadget Store"),
    Product(2,"Samsung Galaxy S24 Ultra",130000,"Mobile","Excellent","Smart Zone"),
    Product(3,"MacBook Air M2",105000,"Laptop","Brand New","Rangpur Gadget Store"),
    Product(4,"AirPods Pro 2",28000,"Headphones","Original","Audio Point"),
    Product(5,"OnePlus 12 256GB",105000,"Mobile","Brand New","Mobile House"),
    Product(6,"Gaming PC RTX 4060",125000,"PC","New","PC Builder BD"),
    Product(7,"Anker 65W Charger",5500,"Charger","Brand New","Accessories Hub"),
    Product(8,"Logitech G102",2200,"Accessories","New","Gaming Zone")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RangpurZoneApp() }
    }
}

@Composable
fun RangpurZoneApp() {
    var tab by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf("main") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var cart by remember { mutableStateOf(listOf<Product>()) }
    var wishlist by remember { mutableStateOf(setOf<Int>()) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = BG, surface = CARD, primary = GREEN,
        onBackground = WHITE, onSurface = WHITE
    )) {
        Surface(Modifier.fillMaxSize(), color = BG) {
            when(page) {
                "login" -> LoginScreen { page = "main" }
                "details" -> selected?.let { ProductDetails(it, { page="main" }, { cart = cart + it; page="cart" }, { 
                    wishlist = if (wishlist.contains(it.id)) wishlist - it.id else wishlist + it.id
                }, wishlist.contains(it.id)) }
                "search" -> SearchScreen { selected = it; page="details" }
                "checkout" -> Checkout(cart) { page="orders" }
                "orders" -> Orders { page="main" }
                "add" -> AddProduct { page="main" }
                "dashboard" -> SellerDashboard { page="main" }
                "notifications" -> Notifications { page="main" }
                "settings" -> Settings { page="main" }
                else -> Scaffold(
                    containerColor = BG,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF0B181D)) {
                            listOf(
                                Triple("Home", Icons.Default.Home, 0),
                                Triple("Categories", Icons.Default.GridView, 1),
                                Triple("Sell", Icons.Default.AddCircle, 2),
                                Triple("Cart", Icons.Default.ShoppingCart, 3),
                                Triple("Profile", Icons.Default.Person, 4)
                            ).forEach { (label, icon, i) ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab=i },
                                    icon = { Icon(icon, null) }, label = { Text(label, fontSize=10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor=GREEN, selectedTextColor=GREEN,
                                        indicatorColor=Color.Transparent,
                                        unselectedIconColor=MUTED, unselectedTextColor=MUTED
                                    )
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad)) {
                        when(tab) {
                            0 -> Home(
                                onSearch={ page="search" },
                                onProduct={ selected=it; page="details" },
                                onNotify={page="notifications"}
                            )
                            1 -> Categories { selected=it; page="details" }
                            2 -> Sell { page="add" ; page="add" }
                            3 -> CartScreen(cart, { page="checkout" })
                            else -> Profile(
                                login={page="login"},
                                orders={page="orders"},
                                dashboard={page="dashboard"},
                                settings={page="settings"}
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable fun TopBar(onNotify:()->Unit) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(GREEN, RoundedCornerShape(13.dp)), contentAlignment=Alignment.Center) {
            Text("RZ", color=Color.Black, fontWeight=FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Rangpur Zone", fontSize=22.sp, fontWeight=FontWeight.Bold)
            Text("Buy • Sell • Connect", color=MUTED, fontSize=12.sp)
        }
        IconButton(onClick=onNotify) { Icon(Icons.Default.NotificationsNone, null) }
    }
}

@Composable fun Home(onSearch:()->Unit, onProduct:(Product)->Unit, onNotify:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(bottom=20.dp)) {
        item {
            TopBar(onNotify)
            SearchBox(onSearch)
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth().padding(horizontal=16.dp), colors=CardDefaults.cardColors(Color(0xFF073D31))) {
                Column(Modifier.padding(20.dp)) {
                    Text("Best Deals On Electronics", fontSize=20.sp, fontWeight=FontWeight.Bold)
                    Text("Mobile • Laptop • PC • Accessories", color=Color(0xFFB9EBD6))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick={}, colors=ButtonDefaults.buttonColors(containerColor=GREEN)) {
                        Text("Shop Now", color=Color.Black, fontWeight=FontWeight.Bold)
                    }
                }
            }
        }
        item { Title("Categories") }
        item {
            val cats=listOf("Mobile","Laptop","PC","Headphones","Charger","Accessories","Gaming","Others")
            LazyRow(contentPadding=PaddingValues(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                items(cats) { c ->
                    Card(Modifier.width(90.dp), colors=CardDefaults.cardColors(CARD)) {
                        Column(Modifier.padding(11.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Devices, null, tint=GREEN, modifier=Modifier.size(28.dp))
                            Text(c, fontSize=11.sp)
                        }
                    }
                }
            }
        }
        item { Title("Featured Products") }
        items(demoProducts) { ProductCard(it,onProduct) }
    }
}

@Composable fun SearchBox(onClick:()->Unit) {
    OutlinedTextField(
        value="", onValueChange={}, readOnly=true, singleLine=true,
        placeholder={Text("Search phones, laptops, accessories…")},
        leadingIcon={Icon(Icons.Default.Search,null)},
        modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp).clickable{onClick()},
        shape=RoundedCornerShape(16.dp),
        colors=OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor=CARD, focusedContainerColor=CARD,
            unfocusedBorderColor=Color.Transparent, focusedBorderColor=GREEN
        )
    )
}

@Composable fun Title(t:String) {
    Row(Modifier.fillMaxWidth().padding(18.dp,18.dp,16.dp,10.dp)) {
        Text(t,fontSize=19.sp,fontWeight=FontWeight.Bold,Modifier.weight(1f))
        Text("See All",color=GREEN,fontSize=13.sp)
    }
}

@Composable fun ProductCard(p:Product,onClick:(Product)->Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp).clickable{onClick(p)},colors=CardDefaults.cardColors(CARD)) {
        Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(78.dp).background(CARD2,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center) {
                Icon(Icons.Default.Devices,null,tint=GREEN,modifier=Modifier.size(38.dp))
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name,fontWeight=FontWeight.SemiBold)
                Text("${p.category} • ${p.condition}",color=MUTED,fontSize=12.sp)
                Text("৳${"% ,d".format(p.price).replace(", ",",")}",color=GREEN,fontWeight=FontWeight.Bold,fontSize=17.sp)
                Text(p.location,color=MUTED,fontSize=11.sp)
            }
            Icon(Icons.Default.FavoriteBorder,null,tint=MUTED)
        }
    }
}

@Composable fun ProductDetails(p:Product,back:()->Unit,buy:()->Unit,toggleWish:()->Unit,wished:Boolean) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)}
            Text("Product Details",fontWeight=FontWeight.Bold,fontSize=19.sp,Modifier.weight(1f))
            IconButton(onClick=toggleWish){Icon(if(wished) Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=GREEN)}
        }
        Box(Modifier.fillMaxWidth().height(230.dp).background(CARD2,RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center){
            Icon(Icons.Default.Devices,null,tint=GREEN,modifier=Modifier.size(90.dp))
        }
        Spacer(Modifier.height(15.dp))
        Text(p.name,fontSize=23.sp,fontWeight=FontWeight.Bold)
        Text("৳${"% ,d".format(p.price).replace(", ",",")}",color=GREEN,fontSize=24.sp,fontWeight=FontWeight.Bold)
        Text("${p.condition} • ${p.category} • ${p.location}",color=MUTED)
        Spacer(Modifier.height(16.dp))
        Text("Seller",fontWeight=FontWeight.Bold,fontSize=18.sp)
        Text(p.seller,color=MUTED)
        Spacer(Modifier.height(16.dp))
        Text("Description",fontWeight=FontWeight.Bold,fontSize=18.sp)
        Text("Verified marketplace listing. Warranty, delivery and seller information can be shown here.",color=MUTED,Modifier.padding(top=7.dp))
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick={},Modifier.weight(1f)){Text("Chat")}
            Button(onClick=buy,Modifier.weight(1f),colors=ButtonDefaults.buttonColors(GREEN)){Text("Buy Now",color=Color.Black,fontWeight=FontWeight.Bold)}
        }
    }
}

@Composable fun Categories(onProduct:(Product)->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Categories",fontSize=25.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        val cats=listOf("Mobile","Laptop","PC","Headphones","Charger","Accessories","Gaming","Other Electronics")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)) {
            items(cats){ c ->
                Card(Modifier.fillMaxWidth().clickable{},colors=CardDefaults.cardColors(CARD)){
                    Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.Devices,null,tint=GREEN);Spacer(Modifier.width(13.dp));Text(c,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null,tint=MUTED)
                    }
                }
            }
        }
    }
}

@Composable fun Sell(openAdd:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Sell",fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("Sell your electronics across Bangladesh.",color=MUTED)
        Spacer(Modifier.height(20.dp))
        Button(onClick=openAdd,Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(GREEN)){Icon(Icons.Default.Add,null,tint=Color.Black);Spacer(Modifier.width(8.dp));Text("Add New Product",color=Color.Black,fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
        Text("Seller tools",fontSize=19.sp,fontWeight=FontWeight.Bold)
        Text("Manage products • Orders • Customers • Sales",color=MUTED,Modifier.padding(top=8.dp))
    }
}

@Composable fun CartScreen(cart:List<Product>,checkout:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Cart (${cart.size})",fontSize=25.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if(cart.isEmpty()) Text("Your cart is empty.",color=MUTED)
        else {
            LazyColumn(Modifier.weight(1f)){items(cart){ProductCard(it,{})}}
            Button(onClick=checkout,Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(GREEN)){Text("Proceed to Checkout",color=Color.Black,fontWeight=FontWeight.Bold)}
        }
    }
}

@Composable fun Profile(login:()->Unit,orders:()->Unit,dashboard:()->Unit,settings:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("My Profile",fontSize=25.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(15.dp))
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(CARD)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.AccountCircle,null,tint=GREEN,modifier=Modifier.size(45.dp));Spacer(Modifier.width(12.dp));Column{Text("Guest User",fontWeight=FontWeight.Bold);Text("Login to manage your account",color=MUTED,fontSize=12.sp)}}}
        Spacer(Modifier.height(14.dp))
        listOf("My Orders" to orders,"Seller Dashboard" to dashboard,"Wishlist" to {},"Settings" to settings).forEach{(t,a)->
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{a()},colors=CardDefaults.cardColors(CARD)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.ChevronRight,null,tint=GREEN);Spacer(Modifier.width(10.dp));Text(t)}}
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick=login,Modifier.fillMaxWidth()){Text("Login / Sign Up")}
    }
}

@Composable fun LoginScreen(done:()->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(55.dp))
        Text("Rangpur Zone",fontSize=30.sp,fontWeight=FontWeight.Bold)
        Text("Your Electronics Marketplace",color=MUTED)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField("",{},label={Text("Phone number or email")},modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField("",{},label={Text("Password")},modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick=done,Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(GREEN)){Text("Login",color=Color.Black,fontWeight=FontWeight.Bold)}
        Text("Don't have an account? Sign Up",color=GREEN,modifier=Modifier.padding(top=18.dp))
    }
}

@Composable fun SearchScreen(open:(Product)->Unit) {
    var q by remember{mutableStateOf("")}
    var category by remember{mutableStateOf("All")}
    val cats=listOf("All","Mobile","Laptop","PC","Headphones","Charger","Accessories")
    val list=demoProducts.filter{(q.isBlank()||it.name.contains(q,true))&&(category=="All"||it.category==category)}
    Column(Modifier.fillMaxSize()) {
        Text("Search Products",fontSize=24.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(18.dp))
        OutlinedTextField(q,{q=it},singleLine=true,placeholder={Text("Search…")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp))
        LazyRow(contentPadding=PaddingValues(16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){items(cats){c->FilterChip(selected=category==c,onClick={category=c},label={Text(c)})}}
        LazyColumn{items(list){ProductCard(it,open)}}
    }
}

@Composable fun Checkout(cart:List<Product>,done:()->Unit) {
    var payment by remember{mutableStateOf("Cash on Delivery")}
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Checkout",fontSize=25.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Delivery Address",fontWeight=FontWeight.Bold,fontSize=18.sp)
        Card(Modifier.fillMaxWidth().padding(top=8.dp),colors=CardDefaults.cardColors(CARD)){Text("Rangpur Sadar, Rangpur\nBangladesh",Modifier.padding(16.dp))}
        Spacer(Modifier.height(18.dp))
        Text("Payment Method",fontWeight=FontWeight.Bold,fontSize=18.sp)
        listOf("Cash on Delivery","bKash","Nagad").forEach{m->Row(Modifier.fillMaxWidth().clickable{payment=m}.padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(payment==m,{payment=m});Text(m)}}
        Spacer(Modifier.weight(1f))
        Button(onClick=done,Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(GREEN)){Text("Place Order • ${cart.size} item(s)",color=Color.Black,fontWeight=FontWeight.Bold)}
    }
}

@Composable fun Orders(back:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Text("My Orders",fontSize=23.sp,fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(CARD)){Column(Modifier.padding(16.dp)){Text("Order #RZ123456789",fontWeight=FontWeight.Bold);Text("iPhone 15 Pro Max",color=MUTED);Spacer(Modifier.height(10.dp));Text("✓ Order Placed",color=GREEN);Text("✓ Confirmed",color=GREEN);Text("• Shipped",color=MUTED);Text("• Out for Delivery",color=MUTED)}}
    }
}

@Composable fun AddProduct(back:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Text("Add Product",fontSize=23.sp,fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick={},Modifier.fillMaxWidth().height(100.dp)){Icon(Icons.Default.AddAPhoto,null);Spacer(Modifier.width(8.dp));Text("Add product photos")}
        Spacer(Modifier.height(10.dp))
        listOf("Product Name","Price","Description").forEach{hint->OutlinedTextField("",{},label={Text(hint)},modifier=Modifier.fillMaxWidth().padding(vertical=5.dp))}
        Button(onClick=back,Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(GREEN)){Text("Publish Product",color=Color.Black,fontWeight=FontWeight.Bold)}
    }
}

@Composable fun SellerDashboard(back:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Text("Seller Dashboard",fontSize=23.sp,fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("Products","24");Stat("Orders","18");Stat("Sales","৳2.45L")}
        Spacer(Modifier.height(18.dp))
        Text("Recent Orders",fontSize=19.sp,fontWeight=FontWeight.Bold)
        demoProducts.take(4).forEach{p->ProductCard(p,{})}
    }
}
@Composable fun Stat(a:String,b:String){Card(Modifier.weight(1f),colors=CardDefaults.cardColors(CARD)){Column(Modifier.padding(12.dp)){Text(a,color=MUTED,fontSize=11.sp);Text(b,fontSize=18.sp,fontWeight=FontWeight.Bold)}}}

@Composable fun Notifications(back:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Text("Notifications",fontSize=23.sp,fontWeight=FontWeight.Bold)}
        listOf("New order received","Your product was sold","New message from buyer","Order delivered").forEach{t->Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(CARD)){Row(Modifier.padding(14.dp)){Icon(Icons.Default.Notifications,null,tint=GREEN);Spacer(Modifier.width(10.dp));Text(t)}}}
    }
}

@Composable fun Settings(back:()->Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Text("Settings",fontSize=23.sp,fontWeight=FontWeight.Bold)}
        listOf("Account Information","Change Password","Delivery Settings","Language","Notifications","Privacy & Security","Help & Support","About Rangpur Zone").forEach{t->Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(CARD)){Row(Modifier.padding(15.dp)){Text(t,Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null,tint=MUTED)}}}
    }
}
