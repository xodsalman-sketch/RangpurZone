# Rangpur Zone — Phone-only APK build

This project includes a GitHub Actions workflow at:
`.github/workflows/build-apk.yml`

After uploading the project to a GitHub repository:
1. Open the repository on your phone.
2. Open **Actions**.
3. Select **Build Rangpur Zone APK**.
4. Tap **Run workflow**.
5. When the run finishes, open the run's **Artifacts** section.
6. Download `RangpurZone-debug-apk`.
7. Extract it and install `app-debug.apk` on your Android phone.

This creates a debug APK for testing. A production Play Store release should use a signed release build/AAB later.
